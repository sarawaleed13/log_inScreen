import 'package:flutter/material.dart';
import 'package:fromscreen/modules/LogInScreen.dart';

void main() {
  runApp(const LoginScreen());
}
